# 这边实现访问数据库的接口类
from tokenize import String
from flask import Flask, render_template, request, Response, jsonify
import time
import pymysql
import pymysql.cursors
import psycopg2
import psycopg2.extras
from foundation.helper.Error import *
from foundation.helper.IoHelper import createRsp
from foundation.helper.Error import ERROR_DB_QUERY
from urllib.parse import urlparse, parse_qs, quote
from foundation.helper.CfgHelper import getGlobalConfig
from foundation.helper.LogHelper import logger
from typing import Optional, Tuple, Any, List, Dict, Union
from foundation.helper.CryptHelper import CryptHelper
import re

class dbHepler():
    def __init__(self):
        self.connection: Optional[Union[pymysql.Connection, psycopg2.extensions.connection]] = None
        self.cursor: Optional[Union[pymysql.cursors.Cursor, psycopg2.extensions.cursor]] = None
        self.db_type: Optional[str] = None  # 'mysql' 或 'postgresql'

    def __del__(self):
        try:
            logger.debug("Database del connection success")
            self.close()
        except Exception as e:
            # 在析构函数中避免抛出异常
            logger.error(f"Error in __del__: {e}")
            pass

    def is_connect(self):
        try:
            ret, res = self.query("select 1")
            return ret
        except Exception as e:
            logger.error(f"数据库连接失败: {e}")
            return False

    # 使用url连接数据库，支持mysql和postgresql
    # 格式为:mysql://10.45.85.21:4000/plca?user=root&password=9@Hs623m1w#qA0Ta
    # 格式为:postgresql://10.45.85.21:5432/plca?user=root&password=9@Hs623m1w#qA0Ta
    def connectWithUrl(self, url: str) -> Tuple[bool, Optional[str]]:
        try:
            if self.cursor is not None or self.connection is not None:
                self.close()
            
            # 解析URL
            new_url = url.replace("@", "%40").replace("#", "%23")
            parsed = urlparse(new_url)
            scheme = parsed.scheme.lower()
            host = parsed.hostname
            database = parsed.path[1:]
            query_params = parse_qs(parsed.query)
            
            # 获取用户名和密码，并进行URL解码
            from urllib.parse import unquote
            user = unquote(query_params.get('user', [''])[0])
            password = unquote(query_params.get('password', [''])[0])
            
            # 解析密码安全解码
            aes_crypt = CryptHelper()
            decrypted = aes_crypt.decrypt(password)
            if decrypted is None:
                return False, "密码解密失败"
            
            # 根据scheme选择数据库类型
            if not host:
                return False, "URL中缺少主机地址"
            
            if scheme in ['mysql', 'tidb']:
                return self._connect_mysql(host, user, decrypted, database, parsed.port or 3306)
            elif scheme in ['postgresql']:
                return self._connect_postgresql(host, user, decrypted, database, parsed.port or 5432)
            else:
                return False, f"不支持的数据库类型: {scheme}"
                
        except Exception as e:
            logger.error(f"Database connection error: {e}")
            self.connection = None
            self.cursor = None
            self.db_type = None
            return False, str(e)
    
    def _connect_mysql(self, host: str, user: str, password: str, database: str, port: int) -> Tuple[bool, Optional[str]]:
        """连接MySQL数据库"""
        try:
            self.connection = pymysql.connect(
                host=host,
                user=user,
                password=password,
                db=database,
                port=int(port),
                cursorclass=pymysql.cursors.DictCursor
            )
            self.cursor = self.connection.cursor()
            self.db_type = 'mysql'
            logger.debug(f"MySQL/TIDB connection success: {host}:{port}:{database}")
            return True, None
        except Exception as e:
            return False, f"MySQL连接失败: {str(e)}"
    
    def _connect_postgresql(self, host: str, user: str, password: str, database: str, port: int) -> Tuple[bool, Optional[str]]:
        """连接PostgreSQL数据库"""
        try:
            self.connection = psycopg2.connect(
                host=host,
                user=user,
                password=password,
                database=database,
                port=int(port)
            )
            # PostgreSQL使用RealDictCursor来返回字典格式的结果
            self.cursor = self.connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            self.db_type = 'postgresql'
            logger.info(f"PostgreSQL connection success: {host}:{port}:{database}")
            return True, None
        except Exception as e:
            return False, f"PostgreSQL连接失败: {str(e)}"

    def connect(self, host: str, user: str, password: str, db: str, port: int, db_type: str = 'mysql') -> Tuple[bool, Optional[str]]:
        """
        连接数据库
        :param db_type: 数据库类型，'mysql' 或 'postgresql'
        """
        try:
            if self.cursor is not None or self.connection is not None:
                self.close()
                
            if db_type.lower() in ['mysql', 'tidb']:
                return self._connect_mysql(host, user, password, db, int(port))
            elif db_type.lower() == 'postgresql':
                return self._connect_postgresql(host, user, password, db, int(port))
            else:
                return False, f"不支持的数据库类型: {db_type}"
            
        except Exception as e:
            logger.error(f"Database connection error: {e}")
            self.connection = None
            self.cursor = None
            self.db_type = None
            return False, str(e)

    def query(self, sql: str, args: Optional[Any] = None) -> Tuple[bool, Any]:
        try:
            if self.cursor is None:
                return False, "数据库连接未建立"
            self.cursor.execute(sql, args)
            result = self.cursor.fetchall()
            return True, result
        except Exception as e:
            logger.error(f"Execute error: {e}")
            # 将错误信息返回给前端
            return False, f"sql:{sql} errMsg:{str(e)}"

    def execute(self, sql: str, args: Optional[Any] = None) -> Tuple[bool, Any]:
        try:
            if self.cursor is None:
                return False, "数据库连接未建立"
            # 执行 SQL 语句
            affected_rows = self.cursor.execute(sql, args)
            return True, affected_rows
        except Exception as e:
            logger.error(f"Execute error: {e}")
            # 回滚事务以避免数据不一致（连接已断开时 rollback 本身也可能抛异常，需捕获）
            if self.connection is not None:
                try:
                    self.connection.rollback()
                except Exception as rb_e:
                    logger.error(f"Execute rollback error: {rb_e}")
            return False, f"sql:{sql} errMsg:{str(e)}"

    def executemany(self, sql: str, args_list: List[Any]) -> Tuple[bool, Any]:
        """
        批量执行SQL语句，适用于批量插入、更新等操作
        :param sql: SQL语句模板，使用%s作为占位符
        :param args_list: 参数列表，每个元素是一个参数元组
        :return: (是否成功, 影响的行数或错误信息)
        """
        try:
            if self.cursor is None:
                return False, "数据库连接未建立"
            
            if not args_list:
                return False, "参数列表不能为空"
            
            # 执行批量 SQL 语句
            affected_rows = self.cursor.executemany(sql, args_list)
            return True, affected_rows
        except Exception as e:
            logger.error(f"ExecuteMany error: {e}")
            # 回滚事务以避免数据不一致（连接已断开时 rollback 本身也可能抛异常，需捕获）
            if self.connection is not None:
                try:
                    self.connection.rollback()
                except Exception as rb_e:
                    logger.error(f"ExecuteMany rollback error: {rb_e}")
            return False, f"sql:{sql} errMsg:{str(e)}"

    def close(self):
        # 关闭游标
        if self.cursor is not None:
            self.cursor.close()
            self.cursor = None

        # 关闭数据库连接
        if self.connection is not None:
            self.connection.close()
            self.connection = None

    def commit(self) -> bool:
        try:
            if self.connection is None:
                return False
            # 执行数据库提交操作
            self.connection.commit()
            return True
        except Exception as e:
            logger.error(f"Commit error: {e}")
            # 回滚事务以避免数据不一致（连接已断开时 rollback 本身也可能抛异常，需捕获）
            if self.connection is not None:
                try:
                    self.connection.rollback()
                except Exception as rb_e:
                    logger.error(f"Commit rollback error: {rb_e}")
            return False


# 内部调用
def dbQuery(cfg_file: str, sql: str, sqlcnts: Optional[str] = None, args: Optional[Any] = None, args_count: Optional[int] = None, db : String = 'data_context') -> Response:
    
    # 使用全局配置
    ret, global_cfg = getGlobalConfig(cfg_file)
    if ret != SUCCESS or global_cfg is None:
        return createRsp(ERROR_DB_QUERY, "加载系统配置失败")

    # 验证数据源配置
    dataSource = global_cfg.getCfgValue("data_source", db)
    if not dataSource:
        return createRsp(ERROR_DB_QUERY, "获取数据源data_source失败")

    dataType = global_cfg.getCfgValue("data_source", 'data_type')
    if dataType not in ["MYSQL", "POSTGRESQL", "TIDB"]:
        return createRsp(ERROR_DB_QUERY, f"数据源data_source类型{dataType}不支持，仅支持MYSQL、POSTGRESQL和TIDB")
    
    db = dbHepler()
    # 将配置中的数据类型转换为小写传递给connect方法，TIDB使用mysql驱动
    db_type = dataType.lower()
    bRet, msg = db.connect(dataSource['host'], dataSource['user'], dataSource['password'],
                                     dataSource['db'], dataSource['port'], db_type)
    if not bRet:
        return createRsp(ERROR_DB_QUERY, f"数据库连接失败:{{{msg}}}")
    
    cnts = 0
    if sqlcnts is not None:
        ret, result = db.query(sqlcnts, args_count)
        if not ret:
            return createRsp(ERROR_DB_QUERY, str(result))
        cnts = result[0]['cnts']

    ret, result = db.query(sql, args)
    if not ret:
        return createRsp(ERROR_DB_QUERY, str(result))

    # 直接返回查询结果，不需要额外处理
    return createRsp(SUCCESS, SUCCESS_MSG, result, cnts)

# 内部调用
def dbExecute(cfg_file: str, sql: str, args: Optional[Any] = None, db : String = 'data_context') -> Response:
    
    # 使用全局配置
    ret, global_cfg = getGlobalConfig(cfg_file)
    if ret != SUCCESS or global_cfg is None:
        return createRsp(ERROR_DB_QUERY, "加载系统配置失败")
    
    # 验证数据源配置
    dataSource = global_cfg.getCfgValue("data_source", db)
    if not dataSource:
        return createRsp(ERROR_DB_QUERY, "获取数据源data_source失败")
    
    dataType = global_cfg.getCfgValue("data_source", 'data_type')
    if dataType not in ["MYSQL", "POSTGRESQL", "TIDB"]:
        return createRsp(ERROR_DB_QUERY, f"数据源data_source类型{dataType}不支持，仅支持MYSQL、POSTGRESQL和TIDB")
    
    db = dbHepler()
    db_type = dataType.lower()
    bRet, msg = db.connect(dataSource['host'], dataSource['user'], dataSource['password'],
                           dataSource['db'], dataSource['port'], db_type)
    if not bRet:
        return createRsp(ERROR_DB_QUERY, f"数据库连接失败:{{{msg}}}")

    ret, result = db.execute(sql, args)
    if not ret:
        return createRsp(ERROR_DB_QUERY, str(result))
    db.commit()
    return createRsp(SUCCESS, SUCCESS_MSG)

def dbQueryLocal(cfg_file: str, sql: str, sqlcnts: Optional[str] = None, args: Optional[Any] = None, args_count: Optional[int] = None, db : String = 'data_context') -> Tuple[int, str, Any, int]:
    
    # 使用全局配置
    ret, global_cfg = getGlobalConfig(cfg_file)
    if ret != SUCCESS or global_cfg is None:
        return ERROR_DB_QUERY, "加载系统配置失败"

    # 验证数据源配置
    dataSource = global_cfg.getCfgValue("data_source", db)
    if not dataSource:
        return ERROR_DB_QUERY, "获取数据源data_source失败"

    dataType = global_cfg.getCfgValue("data_source", 'data_type')
    if dataType not in ["MYSQL", "POSTGRESQL", "TIDB"]:
        return ERROR_DB_QUERY, f"数据源data_source类型{dataType}不支持，仅支持MYSQL、POSTGRESQL和TIDB"
    
    db = dbHepler()
    # 将配置中的数据类型转换为小写传递给connect方法，TIDB使用mysql驱动
    db_type = dataType.lower()
    bRet, msg = db.connect(dataSource['host'], dataSource['user'], dataSource['password'],
                                     dataSource['db'], dataSource['port'], db_type)
    if not bRet:
        return ERROR_DB_QUERY, f"数据库连接失败:{{{msg}}}"
    
    cnts = 0
    if sqlcnts is not None:
        ret, result = db.query(sqlcnts, args_count)
        if not ret:
            return ERROR_DB_QUERY, str(result)
        cnts = result[0]['cnts']

    ret, result = db.query(sql, args)
    if not ret:
        return ERROR_DB_QUERY, str(result)

    # 直接返回查询结果，不需要额外处理
    return SUCCESS, SUCCESS_MSG, result, cnts

# 内部调用
def dbExecuteLocal(cfg_file: str, sql: str, args: Optional[Any] = None, db : String = 'data_context') -> Tuple[int, str]:
    
    # 使用全局配置
    ret, global_cfg = getGlobalConfig(cfg_file)
    if ret != SUCCESS or global_cfg is None:
        return ERROR_DB_QUERY, "加载系统配置失败"
    
    # 验证数据源配置
    dataSource = global_cfg.getCfgValue("data_source", db)
    if not dataSource:
        return ERROR_DB_QUERY, "获取数据源data_source失败"
    
    dataType = global_cfg.getCfgValue("data_source", 'data_type')
    if dataType not in ["MYSQL", "POSTGRESQL", "TIDB"]:
        return ERROR_DB_QUERY, f"数据源data_source类型{dataType}不支持，仅支持MYSQL、POSTGRESQL和TIDB"
    
    db = dbHepler()
    db_type = dataType.lower()
    bRet, msg = db.connect(dataSource['host'], dataSource['user'], dataSource['password'],
                           dataSource['db'], dataSource['port'], db_type)
    if not bRet:
        return ERROR_DB_QUERY, f"数据库连接失败:{{{msg}}}"

    ret, result = db.execute(sql, args)
    if not ret:
        return ERROR_DB_QUERY, str(result)
    db.commit()
    return SUCCESS, SUCCESS_MSG

# 批量操作内部调用
def dbExecuteBatch(cfg_file: str,sql: str, args_list: List[Any], db : String = 'data_context') -> Response:
    """
    批量执行SQL语句的内部调用函数
    :param sql: SQL语句模板，使用%s作为占位符
    :param args_list: 参数列表，每个元素是一个参数元组
    :return: Response对象
    """
    print(f"batch sql:{sql}, batch size:{len(args_list) if args_list else 0}")
    
    # 使用全局配置
    ret, global_cfg = getGlobalConfig(cfg_file)
    if ret != SUCCESS or global_cfg is None:
        return createRsp(ERROR_DB_QUERY, "加载系统配置失败")
    
    # 验证数据源配置
    dataSource = global_cfg.getCfgValue("data_source", db)
    if not dataSource:
        return createRsp(ERROR_DB_QUERY, "获取数据源data_source失败")
    
    dataType = global_cfg.getCfgValue("data_source", 'data_type')
    if dataType not in ["MYSQL", "POSTGRESQL", "TIDB"]:
        return createRsp(ERROR_DB_QUERY, f"数据源data_source类型{dataType}不支持，仅支持MYSQL、POSTGRESQL和TIDB")
    
    # 验证参数
    if not args_list:
        return createRsp(ERROR_DB_QUERY, "批量操作参数列表不能为空")
    
    db = dbHepler()
    db_type = dataType.lower()
    bRet, msg = db.connect(dataSource['host'], dataSource['user'], dataSource['password'],
                           dataSource['db'], dataSource['port'], db_type)
    if not bRet:
        return createRsp(ERROR_DB_QUERY, f"数据库连接失败:{{{msg}}}")

    ret, result = db.executemany(sql, args_list)
    if not ret:
        return createRsp(ERROR_DB_QUERY, str(result))
    
    db.commit()
    return createRsp(SUCCESS, SUCCESS_MSG, {"affected_rows": result})


