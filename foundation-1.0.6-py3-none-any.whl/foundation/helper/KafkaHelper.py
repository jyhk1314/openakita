"""
Kafka 生产者辅助类
发送消息到 Kafka
"""
import time
import hashlib
from collections import deque
from typing import Optional, Tuple, Dict, Any, Deque
# 改造原因：缺依赖时允许模块被导入，等运行到需要 Consumer 时再提示
from confluent_kafka.admin import AdminClient, NewTopic
from confluent_kafka import Consumer as ConfluentConsumer
from confluent_kafka import Producer as ConfluentProducer
from confluent_kafka import KafkaException as ConfluentKafkaException


from foundation.helper.LogHelper import logger
from foundation.helper.CryptHelper import CryptHelper

def _get_md5_password(password):
    """
    获取 MD5 加密的密码
    """
    return hashlib.md5(password.encode('utf-8')).hexdigest()

def _prepare_kafka_config(datasource_config: Dict) -> Dict:
    """
    预处理 Kafka 配置：若配置了 sasl.password，先解密为明文再返回。
    不修改传入的原始 dict，返回新的 dict。
    若 sasl.mechanism 不为 PLAIN，则使用 _get_md5_password 对解密后的密码再次加密。
    """
    config = dict(datasource_config)
    raw_password = config.get("sasl.password")
    if raw_password and str(raw_password).strip():
        raw_password = str(raw_password).strip()
        decrypted = CryptHelper().decrypt(raw_password)
        if decrypted is None:
            raise RuntimeError("sasl.password 解密失败，请确认密文格式正确")
        
        sasl_mechanisms = config.get("sasl.mechanism", "PLAIN")
        if str(sasl_mechanisms).strip().upper() == "PLAIN":
            config["sasl.password"] = decrypted
        else:
            config["sasl.password"] = _get_md5_password(decrypted)
        logger.debug("sasl.password 已完成解密")
    return config

class KafkaProducerHelper:
    """
    Kafka 生产者辅助类
    通过调用者传入的 bootstrap.servers 配置发送消息
    
    初始化时直接使用传入的 datasource_config，不再查询数据库
    """
    
    def __init__(self, datasource_config: Dict):
        """
        初始化 Kafka 生产者辅助类
        
        Args:
            datasource_config: 数据源配置字典，必须包含 'bootstrap.servers' 键
        
        Raises:
            RuntimeError: 如果 bootstrap.servers 为空
        """

        if not datasource_config or not datasource_config.get("bootstrap.servers"):
            error_msg = "datasource_config 中必须包含 'bootstrap.servers' 键"
            logger.error(error_msg)
            raise RuntimeError(error_msg)

        self.kafka_config = _prepare_kafka_config(datasource_config)
        self.producer = None
        logger.info(f"KafkaProducerHelper 初始化成功: bootstrap.servers={self.kafka_config['bootstrap.servers']}")
    
    def send_message(self, topic: str, value: str, key: Optional[str] = None, send_timeout: float = 5.0) -> Tuple[bool, Optional[str]]:
        """
        发送消息到 Kafka
        
        Args:
            topic: Kafka topic 名称
            value: 消息内容（字符串）
            key: 消息键（可选，用于分区）
            send_timeout: 发送超时时间（秒）
        
        Returns:
            Tuple[bool, Optional[str]]: (是否成功, 错误信息)
        """
        try:
            # 验证配置
            if not self.kafka_config["bootstrap.servers"]:
                error_msg = "Kafka 配置未加载，bootstrap.servers 为空"
                logger.error(error_msg)
                return False, error_msg
            
            # 延迟初始化：如果生产者未创建，则创建 
            if self.producer is None:
                logger.info("开始创建 confluent_kafka Producer")
                try:
                    self.producer = ConfluentProducer(self.kafka_config)  # 改造原因：用 confluent_kafka Producer 替代 kafka-python Producer
                    logger.info("confluent_kafka Producer 创建成功")
                except Exception as e:
                    error_msg = f"创建 confluent_kafka Producer 失败: {str(e)}"
                    logger.error(error_msg, exc_info=True)
                    return False, error_msg

            send_value = value.encode("utf-8") if isinstance(value, str) else value  # 改造原因：confluent_kafka 不支持 value_serializer 参数，发送前统一编码
            send_key = key.encode("utf-8") if isinstance(key, str) else key  # 改造原因：confluent_kafka 不支持 key_serializer 参数，发送前统一编码

            try:
                self.producer.produce(topic, value=send_value, key=send_key)
            except BufferError as e:
                error_msg = f"发送消息到 Kafka 失败: {str(e)}" 
                logger.error(error_msg, exc_info=True)
                return False, error_msg

            remaining = self.producer.flush(send_timeout)
            if remaining != 0:
                error_msg = f"发送消息到 Kafka 超时, 超时时间={send_timeout}秒"
                logger.error(error_msg)
                return False, error_msg

            return True, None

        except ConfluentKafkaException as e:
            error_msg = f"发送消息到 Kafka 失败: {str(e)}" 
            logger.error(error_msg, exc_info=True)
            return False, error_msg
        except Exception as e:
            error_msg = f"发送消息时发生异常: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg
    
    def close(self):
        """
        关闭 KafkaProducer
        """
        try: 
            if self.producer:
                self.producer.flush() 
            logger.info("KafkaProducer 已关闭")
        except Exception as e:
            # 析构函数中不应该抛出异常，只记录日志
            logger.error(f"关闭 KafkaProducer 时发生异常: {e}")
        finally:
            self.producer = None 
    
    def __del__(self):
        """
        对象被垃圾回收时自动关闭 KafkaProducer
        """
        self.close()
    
    def __enter__(self):
        """
        上下文管理器入口：支持 with 语句
        使用示例：
            with KafkaProducerHelper('localhost:9092') as producer:
                producer.send_message('topic', 'value')
        """
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        上下文管理器出口：退出 with 语句时自动关闭
        """
        self.close()
        # 返回 False 表示不抑制异常
        return False
    
    def get_config(self) -> Dict[str, Any]:
        """
        获取当前 Kafka 配置信息
        
        Returns:
            Dict[str, Any]: Kafka 配置信息字典
        """
        return self.kafka_config


class KafkaTopicHelper:
    """
    Kafka 主题管理辅助类
    通过 confluent-kafka 实现创建主题等管理功能
    """
    
    def __init__(self, datasource_config: Dict):
        """
        初始化 Kafka 主题管理辅助类
        
        Args:
            datasource_config: 数据源配置字典，必须包含 'bootstrap.servers' 键
        
        Raises:
            RuntimeError: 如果 bootstrap.servers 为空
        """
        if not datasource_config.get('bootstrap.servers'):
            error_msg = "datasource_config 中必须包含 'bootstrap.servers' 键"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
        
        self.kafka_config = _prepare_kafka_config(datasource_config)
        self.admin_client = None

        logger.info(f"KafkaTopicHelper 初始化成功: bootstrap.servers={self.kafka_config['bootstrap.servers']}")
    
    def _get_admin_client(self) -> AdminClient:
        """
        获取 AdminClient 实例（延迟初始化）
        
        Returns:
            AdminClient: Kafka AdminClient 实例
        """
        if AdminClient is None:
            raise RuntimeError("缺少依赖 confluent_kafka，无法使用 KafkaTopicHelper")
        if self.admin_client is None:
            logger.info("开始创建 Kafka AdminClient")
            try:
                self.admin_client = AdminClient(self.kafka_config)
                logger.info("Kafka AdminClient 创建成功")
            except Exception as e:
                error_msg = f"创建 Kafka AdminClient 失败: {str(e)}"
                logger.error(error_msg, exc_info=True)
                raise RuntimeError(error_msg)
        
        return self.admin_client
    
    def topic_exists(self, topic_name: str) -> Tuple[bool, Optional[str]]:
        """
        检查 Kafka 主题是否存在
        
        Args:
            topic_name: 主题名称
        
        Returns:
            Tuple[bool, Optional[str]]: (是否存在, 错误信息)
        """
        try:
            admin_client = self._get_admin_client()
            
            # 获取集群元数据
            metadata = admin_client.list_topics(timeout=10)
            
            # 检查主题是否存在
            exists = topic_name in metadata.topics
            
            if exists:
                logger.debug(f"主题 {topic_name} 已存在")
            else:
                logger.debug(f"主题 {topic_name} 不存在")
            
            return exists, None
            
        except Exception as e:
            error_msg = f"检查主题是否存在时发生异常: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg
    
    def list_topics(self) -> Tuple[Optional[list], Optional[str]]:
        """
        列出所有 Kafka 主题
        
        Returns:
            Tuple[Optional[list], Optional[str]]: (主题列表, 错误信息)
        """
        try:
            admin_client = self._get_admin_client()
            
            # 获取集群元数据
            metadata = admin_client.list_topics(timeout=10)
            
            # 获取所有主题名称
            topics = list(metadata.topics.keys())
            
            logger.info(f"成功获取主题列表，共 {len(topics)} 个主题")
            
            return topics, None
            
        except Exception as e:
            error_msg = f"获取主题列表时发生异常: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return None, error_msg
    
    def create_topic(
        self, 
        topic_name: str, 
        num_partitions: int = 3, 
        replication_factor: int = 1,
        config: Optional[Dict[str, str]] = None,
        skip_if_exists: bool = True
    ) -> Tuple[bool, Optional[str]]:
        """
        创建 Kafka 主题
        
        Args:
            topic_name: 主题名称
            num_partitions: 分区数，默认为 3
            replication_factor: 副本因子，默认为 1
            config: 主题配置参数（可选），如 {'retention.ms': '86400000'}
            skip_if_exists: 如果主题已存在是否跳过（默认为 True），False 则会返回错误
        
        Returns:
            Tuple[bool, Optional[str]]: (是否成功, 错误信息)
        """
        try:
            # 检查主题是否已存在
            exists, error = self.topic_exists(topic_name)
            if error:
                return False, error
            
            if exists:
                if skip_if_exists:
                    logger.info(f"主题 {topic_name} 已存在，跳过创建")
                    return True, None
                else:
                    error_msg = f"主题 {topic_name} 已存在"
                    logger.warning(error_msg)
                    return False, error_msg
            
            admin_client = self._get_admin_client()
            
            # 定义新主题
            topic = NewTopic(
                topic=topic_name,
                num_partitions=num_partitions,
                replication_factor=replication_factor,
                config=config or {}
            )
            
            logger.info(f"开始创建主题: topic={topic_name}, partitions={num_partitions}, replication_factor={replication_factor}")
            
            # 创建主题
            fs = admin_client.create_topics([topic])
            
            # 等待操作完成
            for topic, f in fs.items():
                try:
                    f.result()  # 阻塞直到完成
                    logger.info(f"主题 {topic} 创建成功")
                    return True, None
                except Exception as e:
                    error_msg = f"创建主题 {topic} 失败: {str(e)}"
                    logger.error(error_msg, exc_info=True)
                    return False, error_msg
            
            return True, None
            
        except Exception as e:
            error_msg = f"创建主题时发生异常: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg
    
    def create_topics(
        self, 
        topics: list[Dict[str, any]],
        skip_if_exists: bool = True
    ) -> Tuple[bool, Optional[str]]:
        """
        批量创建 Kafka 主题
        
        Args:
            topics: 主题配置列表，每个元素为字典，包含以下键：
                - topic_name: 主题名称（必填）
                - num_partitions: 分区数（可选，默认为 3）
                - replication_factor: 副本因子（可选，默认为 1）
                - config: 主题配置参数（可选）
            skip_if_exists: 如果主题已存在是否跳过（默认为 True），False 则会返回错误
        
        Returns:
            Tuple[bool, Optional[str]]: (是否全部成功, 错误信息)
        
        Example:
            topics = [
                {'topic_name': 'topic1', 'num_partitions': 3, 'replication_factor': 2},
                {'topic_name': 'topic2', 'num_partitions': 5}
            ]
            success, error = helper.create_topics(topics)
        """
        try:
            admin_client = self._get_admin_client()
            
            # 构建 NewTopic 列表，同时检查主题是否已存在
            new_topics = []
            skipped_topics = []
            
            for topic_config in topics:
                topic_name = topic_config.get('topic_name')
                if not topic_name:
                    error_msg = "主题配置缺少 topic_name 字段"
                    logger.error(error_msg)
                    return False, error_msg
                
                # 检查主题是否已存在
                exists, error = self.topic_exists(topic_name)
                if error:
                    return False, error
                
                if exists:
                    if skip_if_exists:
                        logger.info(f"主题 {topic_name} 已存在，跳过创建")
                        skipped_topics.append(topic_name)
                        continue
                    else:
                        error_msg = f"主题 {topic_name} 已存在"
                        logger.warning(error_msg)
                        return False, error_msg
                
                new_topic = NewTopic(
                    topic=topic_name,
                    num_partitions=topic_config.get('num_partitions', 3),
                    replication_factor=topic_config.get('replication_factor', 1),
                    config=topic_config.get('config', {})
                )
                new_topics.append(new_topic)
            
            # 如果所有主题都已存在，直接返回成功
            if not new_topics:
                logger.info(f"所有主题都已存在，无需创建。跳过的主题: {', '.join(skipped_topics)}")
                return True, None
            
            logger.info(f"开始批量创建 {len(new_topics)} 个主题（跳过 {len(skipped_topics)} 个已存在的主题）")
            
            # 批量创建主题
            fs = admin_client.create_topics(new_topics)
            
            # 等待所有操作完成
            all_success = True
            error_messages = []
            
            for topic, f in fs.items():
                try:
                    f.result()  # 阻塞直到完成
                    logger.info(f"主题 {topic} 创建成功")
                except Exception as e:
                    all_success = False
                    error_msg = f"创建主题 {topic} 失败: {str(e)}"
                    logger.error(error_msg, exc_info=True)
                    error_messages.append(error_msg)
            
            if all_success:
                return True, None
            else:
                return False, "; ".join(error_messages)
            
        except Exception as e:
            error_msg = f"批量创建主题时发生异常: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return False, error_msg
    
    def close(self):
        """
        关闭 AdminClient（confluent-kafka 的 AdminClient 不需要显式关闭）
        """
        if self.admin_client:
            self.admin_client = None
            logger.info("Kafka AdminClient 已关闭")
    
    def __enter__(self):
        """
        上下文管理器入口：支持 with 语句
        使用示例：
            with KafkaTopicHelper('localhost:9092') as helper:
                helper.create_topic('my-topic', num_partitions=3, replication_factor=2)
        """
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        上下文管理器出口：退出 with 语句时自动关闭
        """
        self.close()
        # 返回 False 表示不抑制异常
        return False

class KafkaConsumerHelper:
    """
    Kafka 消费者辅助类
    封装 Kafka poll 与 commit_offset 操作
    """

    def __init__(self, datasource_config: Dict[str, Any]):
        # 正常调用示例：
        #     consumer = KafkaConsumerHelper({
        #         "topic": "REINFORCE_EXECUTION_LOG",
        #         "bootstrap.servers": "127.0.0.1:9092",
        #         "group.id": "reinforce-flink",
        #         "auto.offset.reset": "latest",
        #         "enable.auto.commit": False,
        #         "max.poll.interval.ms": 900000,
        #         "session.timeout.ms": 30000,
        #         "heartbeat.interval.ms": 10000,
        #     })
        # SASL 鉴权示例（用户名密码，常见于 SASL_PLAINTEXT / SASL_SSL）：
        #     consumer = KafkaConsumerHelper({
        #         "topic": "REINFORCE_EXECUTION_LOG",
        #         "bootstrap.servers": "127.0.0.1:9092",
        #         "group.id": "reinforce-flink",
        #         "security.protocol": "SASL_PLAINTEXT",
        #         "sasl.mechanism": "PLAIN",
        #         "sasl.username": "your-username",
        #         "sasl.password": "your-password",
        #         "auto.offset.reset": "latest",
        #         "enable.auto.commit": False,
        #     })
        if not datasource_config or not datasource_config.get("topic"):
            error_msg = "datasource_config 中必须包含 'topic' 键"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
        if not datasource_config.get("bootstrap.servers"):
            error_msg = "datasource_config 中必须包含 'bootstrap.servers' 键"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
        if not datasource_config.get("group.id"):
            error_msg = "datasource_config 中必须包含 'group.id' 键"
            logger.error(error_msg)
            raise RuntimeError(error_msg)

        self.kafka_config: Dict[str, Any] = _prepare_kafka_config(datasource_config)
        self.kafka_config.pop("topic", None)
        self.topic = datasource_config.get("topic")

        self.consumer = None
        self._buffer: Deque[Any] = deque()

        logger.info(
            "KafkaConsumerHelper 初始化成功: topic=%s, group.id=%s, bootstrap.servers=%s",
            self.topic,
            self.kafka_config["group.id"],
            self.kafka_config["bootstrap.servers"],
        )

    def _create_consumer(self):
        if self.consumer is not None:
            return self.consumer
        try:
            self.consumer = ConfluentConsumer(self.kafka_config)
            self.consumer.subscribe([self.topic])
            return self.consumer
        except Exception as e:
            error_msg = f"创建 confluent_kafka Consumer 失败: {str(e)}"
            logger.error(error_msg, exc_info=True)
            self.consumer = None
            return None

    def _prefetch(self, max_records: int, timeout_ms: int) -> int:
        consumer = self._create_consumer()  # 改造原因：延迟初始化，避免构造阶段就触发网络连接/入组
        if not consumer:
            return -1
        timeout_seconds = max(int(timeout_ms), 0) / 1000.0
        appended = 0
        try:
            messages = self.consumer.consume(num_messages=int(max_records), timeout=timeout_seconds) or []  # 改造原因：用 consume 批量拉取，保持 poll(max_records) 的调用习惯
            for msg in messages:
                if msg is None:
                    continue
                if msg.error():
                    logger.error("Kafka消费发生错误: %s", str(msg.error()), exc_info=True)
                    continue
                self._buffer.append(msg)
                appended += 1
        except ConfluentKafkaException as e:
            logger.error("Kafka拉取消息失败: %s", str(e), exc_info=True)
        except Exception as e:
            logger.error("Kafka拉取消息失败: %s", str(e), exc_info=True)
        return appended

    def poll(self, max_records: int = 1000, timeout_ms: int = 30000) -> Optional[Any]:
        if self._buffer:
            return self._buffer.popleft()
        self._prefetch(max_records=max_records, timeout_ms=timeout_ms)
        if self._buffer:
            return self._buffer.popleft()
        return None

    def commit(self, record: Any) -> bool:
        if self.consumer is None:
            logger.error("KafkaConsumer 未初始化")
            return False
        try:
            raw_msg = getattr(record, "raw", record)  # 改造原因：支持传入适配对象或原始 Message
            self.consumer.commit(message=raw_msg, asynchronous=False)  # 改造原因：同步提交，行为更接近原先的“提交即返回结果”
            return True
        except ConfluentKafkaException as e:
            logger.error("Kafka提交offset失败: %s", str(e), exc_info=True)
            return False
        except Exception as e:
            logger.error("Kafka提交offset失败: %s", str(e), exc_info=True)
            return False

    def close(self):
        if self.consumer is None:
            return
        try:
            self.consumer.close()
        except Exception:
            pass
        self.consumer = None

    def __del__(self):
        try:
            if self.consumer is not None:
                self.consumer.close()
                self.consumer = None
        except Exception as e:
            logger.warning(f"析构函数关闭 KafkaConsumer 时发生异常: {e}")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def get_config(self) -> Dict[str, Any]:
        return self.kafka_config
