"""
事件中心插件基类
定义了所有插件必须实现的接口
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, Tuple
from enum import Enum
from docstring_parser import parse

class PluginType(Enum):
    """插件类型枚举"""
    OPERATION_EVENT = "operation_event"  # 定时事件插件
    BUSINESS_EVENT = "business_event"    # 业务事件插件
    EMERGENCY_EVENT = "emergency_event"  # 突发事件插件


class PluginStatus(Enum):
    """插件状态枚举"""
    ENABLED = "enabled"    # 已启用
    DISABLED = "disabled"  # 已禁用
    ERROR = "error"        # 错误状态


class EventPluginBase(ABC):
    """
    事件插件基类
    Args:
        param1 (param_type): param_desc
    """
    
    def __init__(self, plugin_id: str, plugin_name: str, plugin_version:str, plugin_type: PluginType):
        """
        初始化插件
        
        Args:
            plugin_id: 插件唯一标识
            plugin_name: 插件名称
            plugin_type: 插件类型
        """
        self.plugin_id = plugin_id
        self.plugin_name = plugin_name
        self.plugin_type = plugin_type
        self.status = PluginStatus.DISABLED
        self.plugin_version = plugin_version
        
    @abstractmethod
    def initialize(self, config: Dict[str, Any]) -> bool:
        """
        初始化插件
        
        Args:
            config: 插件配置参数
            
        Returns:
            bool: 初始化是否成功
        """
        pass
    
    @abstractmethod
    def collect_events(self, last_collect_time: str, config : Dict = None) -> Tuple[int, str]:
        """
        采集事件数据
        
        Returns:
            Tuple[int, str]: 事件是否触发(0-未处理|1-已触发|2-处理异常), 事件触发详情
        """
        pass
    
    @abstractmethod
    def validate_event(self, event_data: Dict[str, Any]) -> bool:
        """
        验证事件数据是否有效
        
        Args:
            event_data: 事件数据
            
        Returns:
            bool: 数据是否有效
        """
        pass
    
    def get_plugin_info(self) -> Dict[str, Any]:
        """
        获取插件信息
        
        Returns:
            Dict[str, Any]: 插件信息
        """
        return {
            "plugin_id": self.plugin_id,
            "plugin_name": self.plugin_name,
            "plugin_type": self.plugin_type.value,
            "plugin_version": self.plugin_version,
            "status": self.status.value,
            "config": self.config
        }
    
    def get_class_params(self) -> List[Dict[str, Any]]:
        """
        解析子类的文档字符串，提取参数列表
        
        Returns:
            List[Dict[str, Any]]: 参数列表，每个参数包含 arg_name, type_name, description
        """
        try:
            # 解析子类的文档字符串
            parsed = parse(self.__class__.__doc__ or "")
            
            # 提取参数列表
            params = [
                {
                    "arg_name": p.arg_name,
                    "type_name": p.type_name,
                    "description": p.description
                }
                for p in parsed.params
            ]
            
            return params
        except Exception as e:
            return []
    
    def enable(self) -> bool:
        """
        启用插件
        
        Returns:
            bool: 是否成功启用
        """
        try:
            self.status = PluginStatus.ENABLED
            return True
        except Exception as e:
            self.status = PluginStatus.ERROR
            return False
    
    def disable(self) -> bool:
        """
        禁用插件
        
        Returns:
            bool: 是否成功禁用
        """
        try:
            self.status = PluginStatus.DISABLED
            return True
        except Exception as e:
            return False

    @abstractmethod
    def cleanup(self):
        """
        清理插件资源
        """
        pass

class BusinessEventPlugin(EventPluginBase):
    """
    业务事件插件基类
    用于采集业务数据并识别业务事件
    """
    
    def __init__(self, plugin_id: str, plugin_name: str, plugin_version:str):
        super().__init__(plugin_id, plugin_name, plugin_version, PluginType.BUSINESS_EVENT)
    
    @abstractmethod
    def extract_features(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        从业务事件中提取特征
        
        Args:
            event_data: 事件数据
            
        Returns:
            Dict[str, Any]: 提取的特征数据
        """
        pass


class EmergencyEventPlugin(EventPluginBase):
    """
    突发事件插件基类
    用于监控和采集突发异常事件
    """
    
    def __init__(self, plugin_id: str, plugin_name: str, plugin_version:str):
        super().__init__(plugin_id, plugin_name, plugin_version, PluginType.EMERGENCY_EVENT)
    
    @abstractmethod
    def monitor(self) -> Optional[Dict[str, Any]]:
        """
        实时监控突发事件
        
        Returns:
            Optional[Dict[str, Any]]: 检测到的突发事件，无事件则返回None
        """
        pass
    
    @abstractmethod
    def get_severity(self) -> str:
        """
        获取本次突发事件的严重程度
            
        Returns:
            str: 严重程度 (critical/high/medium/low)
        """
        pass

