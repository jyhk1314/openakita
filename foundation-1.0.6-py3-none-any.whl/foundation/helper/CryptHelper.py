import os
import base64
from Crypto.Cipher import AES
from typing import Optional, Tuple

class CryptHelper:
    """
    AES加密解密工具类
    
    使用AES-128-GCM模式进行加密，提供统一的加密解密功能。
    参考JavaScript实现，使用随机生成的密钥和IV，提供更高的安全性。
    """
    
    def __init__(self):
        """初始化AES加密工具"""
        pass
        
    def _generate_random_key(self, key_size: int = 16) -> bytes:
        """
        生成随机密钥
        
        Args:
            key_size (int): 密钥长度，默认16字节(AES-128)
            
        Returns:
            bytes: 随机生成的密钥
        """
        return os.urandom(key_size)
    
    def _generate_random_iv(self, iv_size: int = 12) -> bytes:
        """
        生成随机IV (GCM模式推荐12字节)
        
        Args:
            iv_size (int): IV长度，默认12字节
            
        Returns:
            bytes: 随机生成的IV
        """
        return os.urandom(iv_size)
    
    def encrypt(self, raw_data: str, use_foundation_logger: bool = True) -> Optional[str]:
        """
        使用AES-128-GCM模式加密数据
        
        Args:
            raw_data (str): 需要加密的原始数据
            
        Returns:
            Optional[str]: 加密后的base64字符串，包含IV+密钥+加密数据+认证标签，失败返回None
        """
        try:
            # 生成随机密钥和IV
            key = self._generate_random_key(16)  # AES-128需要16字节密钥
            iv = self._generate_random_iv(12)    # GCM模式推荐12字节IV
            
            # 创建AES-GCM加密器
            cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
            
            # 加密数据
            encrypted_data, auth_tag = cipher.encrypt_and_digest(raw_data.encode('utf-8'))
            
            # 按照JavaScript的格式拼接：IV + 密钥 + 加密数据 + 认证标签
            combined_data = iv + key + encrypted_data + auth_tag
            
            # 返回base64编码的结果
            return base64.b64encode(combined_data).decode('utf-8')
            
        except Exception as e:
            if use_foundation_logger:
                from foundation.helper.LogHelper import logger
                logger.error(f"数据加密失败: {e}")
            return None
    
    def decrypt(self, enc_data: str, use_foundation_logger: bool = True) -> Optional[str]:
        """
        解密数据
        
        Args:
            enc_data (str): base64编码的加密数据
            
        Returns:
            Optional[str]: 解密后的原始数据，失败返回None
        """
        try:
            # 解码base64数据
            combined_data = base64.b64decode(enc_data)
            
            # 按照格式解析：IV(12字节) + 密钥(16字节) + 加密数据 + 认证标签(16字节)
            iv = combined_data[:12]
            key = combined_data[12:28]
            auth_tag = combined_data[-16:]
            encrypted_data = combined_data[28:-16]
            
            # 创建AES-GCM解密器
            cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
            
            # 解密数据
            decrypted_data = cipher.decrypt_and_verify(encrypted_data, auth_tag)
            
            return decrypted_data.decode('utf-8')
            
        except Exception as e:
            if use_foundation_logger:
                from foundation.helper.LogHelper import logger
                logger.error(f"数据解密失败: {e}")
            return None
    
    def aes_encrypt(self, content: str, use_foundation_logger: bool = True) -> Optional[str]:
        """
        通用AES加密方法（对应JavaScript的AESEncrypt）
        
        Args:
            content (str): 需要加密的内容
            use_fondation_logger (bool): 是否使用foundation的logger，默认True
            
        Returns:
            Optional[str]: 加密后的base64字符串，失败返回None
        """
        return self.encrypt(content, use_foundation_logger)
    
    def aes_decrypt_from_parts(self, key: bytes, iv: bytes, enc_data: bytes, auth_tag: bytes, use_foundation_logger: bool = True) -> Optional[str]:
        """
        从分离的组件解密数据（对应JavaScript的AESDecrypt）
        
        Args:
            key (bytes): 解密密钥
            iv (bytes): 初始化向量
            enc_data (bytes): 加密数据
            auth_tag (bytes): 认证标签
            use_foundation_logger (bool): 是否使用foundation的logger，默认True
            
        Returns:
            Optional[str]: 解密后的字符串，失败返回None
        """
        try:
            cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
            decrypted_data = cipher.decrypt_and_verify(enc_data, auth_tag)
            return decrypted_data.decode('utf-8')
        except Exception as e:
            if use_foundation_logger:
                from foundation.helper.LogHelper import logger
                logger.error(f"分组解密失败: {e}")
            return None
    






